package vn.shopttcn.util;

import vn.shopttcn.constant.GlobalConstant;

public class ConstantUtil {

	public static int getShip() {
		return GlobalConstant.SHIP;
	}

}
